package cc.mochi.meowgui;

import cc.mochi.*;
import cc.mochi.Module;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.IntConsumer;

/**
 * Meow GUI, dropdown layout: one column per category side by side (like the Wisp screenshot),
 * header with a collapse chevron, enabled modules as light pills, a dropdown arrow on every module
 * for its settings, and a top bar with name, active count, search, theme and close.
 *
 * Reads every module straight from ModuleManager; nothing in the modules is edited.
 * Touch friendly: drag anywhere to pan, tap a module to toggle, tap its arrow for settings.
 * Cheap to draw: lists are cached, only visible columns/rows are drawn, no per-pixel effects.
 * Right Shift is handled by the original client (not re-bound here); while this screen is open
 * Right Shift / Esc / X closes it.
 */
public class MeowGuiScreen extends Screen {
    // ---- persistent UI state (survives close / reopen) ----
    private static boolean dark = true;
    private static String search = "";
    private static final Set<ModuleCategory> collapsed = new HashSet<>();
    private static boolean topo = true;
    private static float savedScroll, savedHScroll;

    // ---- theme ----
    private int cPanel, cSoft, cLine, cLineStrong, cText, cMuted, cAccent, cInk, cTrackOff, cTrackOn, cKnobOff, cKnobOn, cPillOn, cPillInk, cBar;
    private static final int GREEN = 0xFF71DFA0;
    private static final int[] HUE = new int[48];
    static { for (int i = 0; i < HUE.length; i++) HUE[i] = 0xFF000000 | Gfx.hsb(i / (float) HUE.length, 0.62f, 1f); }

    private void applyTheme() {
        if (dark) {
            cPanel = 0xEC09090C; cBar = 0xF00B0B10; cSoft = 0x90242430; cLine = 0x2EFFFFFF; cLineStrong = 0x66FFFFFF;
            cText = 0xFFF2F2F6; cMuted = 0xFFA8A8B4; cAccent = 0xFFE6E6EE; cInk = 0xFF111114;
            cTrackOff = 0xFF454452; cTrackOn = 0xFFDADAE4; cKnobOff = 0xFFE5E2EF; cKnobOn = 0xFF202028;
            cPillOn = 0xFFE8E8EE; cPillInk = 0xFF121216;
        } else {
            cPanel = 0xF2F4F4F8; cBar = 0xF5F8F8FB; cSoft = 0xFFE0E0E8; cLine = 0x40000000; cLineStrong = 0x80222230;
            cText = 0xFF1A1A22; cMuted = 0xFF666672; cAccent = 0xFF22222A; cInk = 0xFFFFFFFF;
            cTrackOff = 0xFFC4C4D0; cTrackOn = 0xFF55555F; cKnobOff = 0xFFFFFFFF; cKnobOn = 0xFFFFFFFF;
            cPillOn = 0xFF22222A; cPillInk = 0xFFFFFFFF;
        }
    }

    private static final class Hit {
        int x, y, w, h, clipT, clipB;
        Runnable click;
        IntConsumer drag;
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Map<Module, Float> expandAnim = new HashMap<>();
    private final Map<Module, Float> toggleAnim = new HashMap<>();
    private final Map<Object, Float> settingAnim = new HashMap<>();
    private final Set<Module> expanded = new HashSet<>();

    private final List<ModuleCategory> cats = new ArrayList<>();
    private final Map<ModuleCategory, List<Module>> byCat = new LinkedHashMap<>();
    private final Map<Module, String> lowerNames = new HashMap<>();
    private final List<Module> all = new ArrayList<>();
    private final Map<ModuleCategory, int[]> topoCache = new HashMap<>();

    private float openAnim, scroll, scrollTarget, hscroll, contentH, contentW;
    private long lastNs = System.nanoTime();
    private boolean dragged;
    private Hit pressHit, activeDrag;
    private double pressX, pressY;
    private Module listenModule;
    private KeybindSetting listenSetting;
    private boolean searchFocus;
    private int clipT = Integer.MIN_VALUE, clipB = Integer.MAX_VALUE;
    private int areaY, areaH;
    private int mx, my;
    private float anim;
    // The key press that OPENS this screen is also delivered to it by vanilla in the same onKey
    // call. Mobile launchers send press+release instantly, so the toggle key only closes after the
    // opening key was released, or after a safety timeout.
    private final long openedNs = System.nanoTime();
    private boolean closeArmed;

    public MeowGuiScreen() {
        super(Text.literal("Meow Client"));
        applyTheme();
        scroll = scrollTarget = savedScroll;
        hscroll = savedHScroll;
        ModuleManager mm = MochiClient.INSTANCE.getModuleManager();
        for (ModuleCategory c : ModuleCategory.values()) {
            List<Module> list = new ArrayList<>();
            for (Object o : mm.getModulesByCategory(c)) {
                Module m = (Module) o;
                list.add(m);
                all.add(m);
                lowerNames.put(m, m.getName().toLowerCase(Locale.ROOT));
            }
            if (list.isEmpty()) continue;
            cats.add(c);
            byCat.put(c, list);
        }
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        savedScroll = scrollTarget;
        savedHScroll = hscroll;
        super.removed();
    }

    // ------------------------------------------------------------------ helpers
    private int ca(int argb) { return Gfx.mulA(argb, anim); }

    private boolean over(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= Math.max(y, clipT) && my < Math.min(y + h, clipB);
    }

    private void sw(int x, int y, float t) {
        Gfx.roundRect(x, y, 22, 11, 5, ca(Gfx.lerp(cTrackOff, cTrackOn, t)));
        Gfx.circle(x + 6 + Math.round(10 * t), y + 5, 4, ca(Gfx.lerp(cKnobOff, cKnobOn, t)));
    }

    private int enabledCount() {
        int n = 0;
        for (Module m : all) if (m.isEnabled()) n++;
        return n;
    }

    private boolean matches(Module m) {
        return search.isEmpty() || lowerNames.get(m).contains(search.toLowerCase(Locale.ROOT));
    }

    private void toggleTheme() { dark = !dark; applyTheme(); }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        openAnim = Math.min(1f, openAnim + dt * 7f);
        anim = 1f - (1f - openAnim) * (1f - openAnim) * (1f - openAnim);
        mx = mouseX; my = mouseY;
        Gfx.begin(ctx);
        hits.clear();
        clipT = Integer.MIN_VALUE; clipB = Integer.MAX_VALUE;

        Gfx.rect(0, 0, width, height, Gfx.rgba(0x05040A, (int) (70 * anim)));

        int barH = 24;
        areaY = barH + 8;
        areaH = height - areaY;
        drawColumns();
        drawTopBar(barH);
    }

    // ------------------------------------------------------------------ top bar
    private void drawTopBar(int barH) {
        int bw = Math.min(width - 8, 320);
        int bx = (width - bw) / 2, by = 4 - (int) ((1f - anim) * 8);
        Gfx.roundRect(bx, by, bw, barH, 8, ca(cBar));
        Gfx.roundOutline(bx, by, bw, barH, 8, 1, ca(cLineStrong));
        int x = bx + 6;
        Gfx.roundRect(x, by + 4, 16, 16, 5, ca(cPillOn));
        Gfx.textCentered("M", x + 8, by + 8, ca(cPillInk));
        x += 21;
        if (bw >= 240) {
            Gfx.bold("MEOW", x, by + 8, ca(cText));
            x += Gfx.boldWidth("MEOW") + 6;
        }
        String act = enabledCount() + " ACTIVE";
        int pw = Gfx.textWidth(act) + 12;
        Gfx.roundRect(x, by + 5, pw, 14, 7, ca(cPillOn));
        Gfx.text(act, x + 6, by + 8, ca(cPillInk));
        x += pw + 5;
        int rightEdge = bx + bw - 6 - 3 * 18 - 4;
        drawSearch(x, by + 4, rightEdge - x, 16);
        int b1 = rightEdge + 4, b2 = b1 + 18, b3 = b2 + 18;
        drawIconButton(b1, by + 4, "~", () -> topo = !topo);
        drawIconButton(b2, by + 4, "o", this::toggleTheme);
        drawIconButton(b3, by + 4, "x", this::close);
    }

    private void drawIconButton(int x, int y, String label, Runnable click) {
        boolean hv = over(x, y, 16, 16);
        Gfx.roundRect(x, y, 16, 16, 5, ca(hv ? cSoft : Gfx.rgba(cText, 18)));
        Gfx.roundOutline(x, y, 16, 16, 5, 1, ca(cLine));
        Gfx.textCentered(label, x + 8, y + 4, ca(cText));
        addHit(x - 2, y - 2, 20, 20, click, null);
    }

    private void drawSearch(int x, int y, int w, int h) {
        if (w < 24) return;
        Gfx.roundRect(x, y, w, h, 6, ca(searchFocus ? cSoft : Gfx.rgba(cText, 14)));
        Gfx.roundOutline(x, y, w, h, 6, 1, ca(searchFocus ? cLineStrong : cLine));
        String shown;
        int color;
        if (search.isEmpty() && !searchFocus) { shown = "Search modules..."; color = cMuted; }
        else { shown = search + (searchFocus && (System.nanoTime() / 500_000_000L) % 2 == 0 ? "_" : ""); color = cText; }
        boolean placeholder = search.isEmpty() && !searchFocus;
        while (shown.length() > 1 && Gfx.textWidth(shown) > w - 10) shown = placeholder ? shown.substring(0, shown.length() - 1) : shown.substring(1);
        Gfx.text(shown, x + 5, y + 4, ca(color));
        addHit(x, y, w, h, () -> searchFocus = true, null);
    }

    // ------------------------------------------------------------------ columns
    private static final int COL_W = 104, COL_GAP = 6, HEAD_H = 18, RH = 15, ROW_GAP = 3, KEY_ROW = 22, DESC_H = 12;

    private void drawColumns() {
        List<ModuleCategory> shown = new ArrayList<>();
        Map<ModuleCategory, List<Module>> items = new HashMap<>();
        for (ModuleCategory c : cats) {
            List<Module> l = new ArrayList<>();
            for (Module m : byCat.get(c)) if (matches(m)) l.add(m);
            if (l.isEmpty()) continue;
            shown.add(c);
            items.put(c, l);
        }
        int n = shown.size();
        contentW = n * COL_W + Math.max(0, n - 1) * COL_GAP + 12;
        float maxH = Math.max(0, contentW - width);
        hscroll = Math.max(0, Math.min(maxH, hscroll));
        float maxV = Math.max(0, contentH - areaH + 6);
        scrollTarget = Math.max(0, Math.min(maxV, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.4f;
        if (Math.abs(scrollTarget - scroll) < 0.4f) scroll = scrollTarget;

        if (n == 0) {
            Gfx.textCentered("No modules found.", width / 2, areaY + 30, ca(cText));
            contentH = 0;
            return;
        }
        int startX = contentW <= width ? (width - (int) contentW) / 2 + 6 : 6 - Math.round(hscroll);
        int baseY = areaY - Math.round(scroll);

        Gfx.scissor(0, areaY, width, areaH);
        int sT = clipT, sB = clipB;
        clipT = areaY; clipB = areaY + areaH;
        int maxBottom = 0;
        for (int i = 0; i < n; i++) {
            ModuleCategory c = shown.get(i);
            int x = startX + i * (COL_W + COL_GAP);
            int h = drawColumn(c, items.get(c), x, baseY);
            maxBottom = Math.max(maxBottom, h);
        }
        contentH = maxBottom;
        clipT = sT; clipB = sB;
        Gfx.unscissor();

        if (contentH > areaH) {
            int bh = Math.max(16, (int) ((long) areaH * areaH / contentH));
            int by = areaY + (int) ((areaH - bh) * (scroll / Math.max(1f, contentH - areaH)));
            Gfx.roundRect(width - 3, by, 2, bh, 1, ca(Gfx.rgba(cAccent, 150)));
        }
    }

    private int columnHeight(List<Module> mods, boolean isCollapsed) {
        if (isCollapsed) return HEAD_H + 4;
        int h = HEAD_H + 3;
        for (Module m : mods) h += rowHeight(m) + ROW_GAP;
        return h + 1;
    }

    /** @return the column's height */
    private int drawColumn(ModuleCategory c, List<Module> mods, int x, int y) {
        boolean isCol = collapsed.contains(c);
        for (Module m : mods) animateOnly(m);
        int total = columnHeight(mods, isCol);
        if (x + COL_W <= 0 || x >= width || y + total <= clipT || y >= clipB) return total;

        Gfx.roundRect(x, y, COL_W, total, 8, ca(cPanel));
        if (topo) drawTopo(c, x, y, total);
        Gfx.roundOutline(x, y, COL_W, total, 8, 1, ca(cLine));
        Gfx.bold(Gfx.fit(c.getName(), COL_W - 34), x + 8, y + 6, ca(cText));
        String cnt = String.valueOf(mods.size());
        Gfx.text(cnt, x + COL_W - 24 - Gfx.textWidth(cnt), y + 6, ca(cMuted));
        Gfx.text(isCol ? "v" : "^", x + COL_W - 14, y + 6, ca(cMuted));
        addHit(x, y, COL_W, HEAD_H, () -> { if (!collapsed.remove(c)) collapsed.add(c); }, null);
        if (isCol) return total;

        int yy = y + HEAD_H + 1;
        for (Module m : mods) yy += drawRow(m, x + 4, yy, COL_W - 8) + ROW_GAP;
        return total;
    }

    // ------------------------------------------------------------------ topography background
    private static final int TOPO_H = 640, TOPO_LEVELS = 5;

    /**
     * Contour lines of a smooth noise field, built once per column as horizontal runs
     * packed as (y << 16 | x << 8 | cells). Cells are 2px wide, rows are 1px, so steep lines stay
     * solid and flat lines stay thin. Only the visible slice is drawn each frame.
     */
    private int[] buildTopo(ModuleCategory c) {
        Random r = new Random(c.ordinal() * 7919L + 13L);
        int waves = 4;
        double[] fx = new double[waves], fy = new double[waves], ph = new double[waves];
        for (int i = 0; i < waves; i++) {
            double ang = r.nextDouble() * Math.PI * 2, f = 0.014 + r.nextDouble() * 0.026;
            fx[i] = Math.cos(ang) * f; fy[i] = Math.sin(ang) * f; ph[i] = r.nextDouble() * 6.28;
        }
        int cols = COL_W / 2;
        int[] prev = new int[cols + 1], cur = new int[cols + 1];
        int[] out = new int[1024];
        int n = 0;
        for (int y = 0; y <= TOPO_H; y++) {
            for (int cx = 0; cx <= cols; cx++) {
                double f = 0;
                for (int i = 0; i < waves; i++) f += Math.sin(fx[i] * cx * 2 + fy[i] * y + ph[i]);
                f = f / waves * 0.5 + 0.5;
                cur[cx] = (int) Math.floor(Math.max(0, Math.min(0.999, f)) * TOPO_LEVELS);
            }
            if (y > 0) {
                int runStart = -1;
                for (int cx = 1; cx < cols - 1; cx++) {
                    boolean mark = cur[cx] != cur[cx + 1] || cur[cx] != prev[cx];
                    if (mark && runStart < 0) runStart = cx;
                    if ((!mark || cx == cols - 2) && runStart >= 0) {
                        int len = (mark ? cx + 1 : cx) - runStart;
                        if (n == out.length) out = Arrays.copyOf(out, n * 2);
                        out[n++] = ((y - 1) << 16) | (runStart * 2 << 8) | Math.min(255, len);
                        runStart = -1;
                    }
                }
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return Arrays.copyOf(out, n);
    }

    private void drawTopo(ModuleCategory c, int x, int y, int total) {
        int[] d = topoCache.computeIfAbsent(c, this::buildTopo);
        int minRy = Math.max(0, clipT - y - 1), maxRy = Math.min(Math.min(total - 3, TOPO_H), clipB - y);
        if (maxRy <= minRy) return;
        int lo = 0, hi = d.length;
        while (lo < hi) { int mid = (lo + hi) >>> 1; if ((d[mid] >>> 16) < minRy) lo = mid + 1; else hi = mid; }
        int color = ca(Gfx.rgba(dark ? 0xFFFFFF : 0x22222A, dark ? 46 : 50));
        for (int i = lo; i < d.length; i++) {
            int v = d[i], ry = v >>> 16;
            if (ry >= maxRy) break;
            if (ry < 2) continue;
            Gfx.rect(x + ((v >> 8) & 255), y + ry, (v & 255) * 2, 1, color);
        }
    }

    // ------------------------------------------------------------------ module rows
    private List<Setting> visibleSettings(Module m) {
        List<Setting> out = new ArrayList<>();
        for (Object o : m.getSettings()) {
            Setting s = (Setting) o;
            if (s.isVisible() && s != m.getKeybind()) out.add(s);
        }
        return out;
    }

    private int settingH(Setting s) {
        if (s instanceof DoubleSetting || s instanceof DecimalSetting) return 30;
        if (s instanceof ColorSetting) return 44;
        return 22;
    }

    private int expandedFull(Module m, List<Setting> st) {
        String d = m.getDescription();
        int full = KEY_ROW + (d != null && !d.isEmpty() ? DESC_H : 0);
        for (Setting s : st) full += settingH(s);
        return full;
    }

    private void animateOnly(Module m) {
        approach(expandAnim, m, expanded.contains(m) ? 1f : 0f, 0.3f);
        approach(toggleAnim, m, m.isEnabled() ? 1f : 0f, 0.3f);
    }

    private int rowHeight(Module m) {
        float ex = expandAnim.getOrDefault(m, expanded.contains(m) ? 1f : 0f);
        if (ex <= 0.01f && !expanded.contains(m)) return RH;
        return RH + (int) (expandedFull(m, visibleSettings(m)) * ex) + (ex > 0.01f ? 3 : 0);
    }

    private int drawRow(Module m, int x, int y, int w) {
        boolean on = m.isEnabled();
        boolean isExp = expanded.contains(m);
        float t = toggleAnim.getOrDefault(m, on ? 1f : 0f);
        float ex = expandAnim.getOrDefault(m, isExp ? 1f : 0f);
        List<Setting> st = null;
        int full = 0;
        if (ex > 0.01f || isExp) { st = visibleSettings(m); full = expandedFull(m, st); }
        int h = RH + (int) (full * ex) + (ex > 0.01f ? 3 : 0);
        if (y + h <= clipT || y >= clipB) return h;

        // pill: light when enabled, flat when off
        if (t > 0.01f) Gfx.roundRect(x, y, w, RH, 6, ca(Gfx.mulA(cPillOn, t)));
        else if (over(x, y, w, RH)) Gfx.roundRect(x, y, w, RH, 6, ca(Gfx.rgba(cText, 20)));
        int textColor = Gfx.lerp(cMuted, cPillInk, t);
        String name = Gfx.fit(m.getName(), w - 30);
        Gfx.textCentered(name, x + w / 2 + 5, y + 4, ca(textColor));
        Gfx.text(isExp ? "^" : "v", x + 6, y + 4, ca(Gfx.lerp(cMuted, cPillInk, t)));
        addHit(x, y, 20, RH, () -> { if (!expanded.remove(m)) expanded.add(m); }, null);
        addHit(x + 20, y, w - 20, RH, m::toggle, null);

        if (ex > 0.01f && st != null) {
            Gfx.roundRect(x, y + RH + 1, w, h - RH - 2, 5, ca(cSoft));
            Gfx.scissor(x + 1, y + RH + 1, w - 2, h - RH - 2);
            int sy = y + RH + 3;
            int ix = x + 6, iw = w - 12;
            float sa = ex;
            String d = m.getDescription();
            if (d != null && !d.isEmpty()) {
                Gfx.text(Gfx.fit(d, iw), ix, sy + 1, ca(Gfx.mulA(cMuted, sa)));
                sy += DESC_H;
            }
            drawKeybindRow(m, ix, sy, iw, sa);
            sy += KEY_ROW;
            for (Setting s : st) { drawSetting(s, ix, sy, iw, sa); sy += settingH(s); }
            Gfx.unscissor();
        }
        return h;
    }

    private void keyChip(int x, int y, int w, String v, boolean listening, float sa) {
        int cw = Math.max(30, Gfx.textWidth(v) + 12);
        Gfx.roundRect(x + w - cw, y + 3, cw, 15, 5, ca(Gfx.mulA(listening ? cAccent : cTrackOff, sa)));
        Gfx.textCentered(Gfx.fit(v, cw - 6), x + w - cw / 2, y + 7, ca(Gfx.mulA(listening ? cInk : cText, sa)));
    }

    private void drawKeybindRow(Module m, int x, int y, int w, float sa) {
        Gfx.text("Keybind", x, y + 7, ca(Gfx.mulA(cText, sa)));
        boolean l = listenModule == m;
        String v = l ? "..." : KeyNames.of(m.getKeyCode());
        keyChip(x, y, w, v, l, sa);
        addHit(x + w / 3, y, w * 2 / 3, KEY_ROW, () -> { listenModule = m; listenSetting = null; }, null);
    }

    // ------------------------------------------------------------------ settings widgets
    private void drawSetting(Setting s, int x, int y, int w, float sa) {
        int white = ca(Gfx.mulA(cText, sa));
        int dim = ca(Gfx.mulA(cMuted, sa));
        if (s instanceof BooleanSetting b) {
            Gfx.text(Gfx.fit(b.getName(), w - 30), x, y + 7, white);
            float t = approach(settingAnim, b, b.getValue() ? 1f : 0f, 0.35f);
            sw(x + w - 22, y + 5, t);
            addHit(x, y, w, 22, b::toggle, null);
        } else if (s instanceof DoubleSetting d) {
            String val = d.getStep() >= 1 ? String.valueOf((int) d.getValue()) : String.format(Locale.ROOT, "%.2f", d.getValue());
            Gfx.text(Gfx.fit(d.getName(), w - 40), x, y + 3, white);
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 3, dim);
            slider(x, y + 16, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), sa,
                    px -> {
                        double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        double v = d.getMinimum() + f * (d.getMaximum() - d.getMinimum());
                        if (d.getStep() > 0) v = Math.round(v / d.getStep()) * d.getStep();
                        d.setValue(Math.max(d.getMinimum(), Math.min(d.getMaximum(), v)));
                    });
        } else if (s instanceof DecimalSetting d) {
            Gfx.text(Gfx.fit(d.getName(), w - 40), x, y + 3, white);
            String val = d.formatValue();
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 3, dim);
            slider(x, y + 16, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), sa,
                    px -> {
                        double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        d.setValue(d.getMinimum() + f * (d.getMaximum() - d.getMinimum()));
                    });
        } else if (s instanceof ChoiceSetting c) {
            Gfx.text(Gfx.fit(c.getName(), w / 2 - 4), x, y + 7, white);
            String v = Gfx.fit(c.getSelected(), w / 2 - 12);
            int cw = Gfx.textWidth(v) + 16;
            Gfx.roundRect(x + w - cw, y + 3, cw, 15, 5, ca(Gfx.mulA(cTrackOff, sa)));
            Gfx.textCentered(v, x + w - cw / 2, y + 7, ca(Gfx.mulA(cAccent, sa)));
            addHit(x + w / 2 - 10, y, w / 2 + 10, 22, c::cycle, null);
        } else if (s instanceof ColorSetting c) {
            Gfx.text(Gfx.fit(c.getName(), w - 24), x, y + 3, white);
            Gfx.circle(x + w - 6, y + 7, 5, ca(Gfx.mulA(0xFF000000 | c.getRgb(), sa)));
            float[] hsb = c.getHsb();
            hueBar(x, y + 16, w, sa);
            Gfx.circle(x + (int) (hsb[0] * w), y + 19, 4, ca(Gfx.mulA(0xFFFFFFFF, sa)));
            addHit(x, y + 13, w, 14, null, px -> {
                float[] c2 = c.getHsb();
                c.setHsb(Math.max(0f, Math.min(1f, (px - x) / (float) w)), Math.max(0.55f, c2[1]), Math.max(0.6f, c2[2]));
            });
            int base = 0xFF000000 | Gfx.hsb(hsb[0], hsb[1], 1f);
            int step = Math.max(4, w / 24);
            for (int i = 0; i < w; i += step) Gfx.rect(x + i, y + 30, Math.min(step, w - i), 6, ca(Gfx.mulA(Gfx.lerp(0xFF000000, base, i / (float) w), sa)));
            Gfx.circle(x + (int) (hsb[2] * w), y + 33, 4, ca(Gfx.mulA(0xFFFFFFFF, sa)));
            addHit(x, y + 27, w, 14, null, px -> {
                float[] c2 = c.getHsb();
                c.setHsb(c2[0], c2[1], Math.max(0.05f, Math.min(1f, (px - x) / (float) w)));
            });
        } else if (s instanceof KeybindSetting k) {
            Gfx.text(Gfx.fit(k.getName(), w - 54), x, y + 7, white);
            boolean l = listenSetting == k;
            keyChip(x, y, w, l ? "..." : KeyNames.of(k.getKeyCode()), l, sa);
            addHit(x + w / 2, y, w / 2, 22, () -> { listenSetting = k; listenModule = null; }, null);
        } else if (s instanceof StringSetting st) {
            Gfx.text(Gfx.fit(st.getName(), w / 2), x, y + 7, white);
            String v = Gfx.fit(st.getValue3(), w / 2 - 6);
            Gfx.text(v, x + w - Gfx.textWidth(v), y + 7, dim);
        } else {
            Gfx.text(Gfx.fit(s.getName(), w), x, y + 7, white);
        }
    }

    private void hueBar(int x, int y, int w, float sa) {
        int n = HUE.length;
        for (int i = 0; i < n; i++) {
            int x0 = x + i * w / n, x1 = x + (i + 1) * w / n;
            Gfx.rect(x0, y, x1 - x0, 6, ca(Gfx.mulA(HUE[i], sa)));
        }
    }

    private void slider(int x, int y, int w, float f, float sa, IntConsumer drag) {
        f = Math.max(0f, Math.min(1f, f));
        Gfx.roundRect(x, y + 2, w, 4, 2, ca(Gfx.mulA(cTrackOff, sa)));
        int fw = Math.max(4, (int) (w * f));
        Gfx.roundRect(x, y + 2, fw, 4, 2, ca(Gfx.mulA(cAccent, sa)));
        Gfx.circle(x + fw, y + 4, 4, ca(Gfx.mulA(cAccent, sa)));
        addHit(x - 5, y - 8, w + 10, 22, null, drag);
    }

    // ------------------------------------------------------------------ input
    private void addHit(int x, int y, int w, int h, Runnable click, IntConsumer drag) {
        Hit hit = new Hit();
        hit.x = x; hit.y = y; hit.w = w; hit.h = h; hit.click = click; hit.drag = drag;
        hit.clipT = clipT; hit.clipB = clipB;
        hits.add(hit);
    }

    private Hit hitAt(double px, double py) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (px >= h.x && px < h.x + h.w && py >= Math.max(h.y, h.clipT) && py < Math.min(h.y + h.h, h.clipB)) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double x = click.x(), y = click.y();
        dragged = false; activeDrag = null; pressHit = null;
        pressX = x; pressY = y;
        searchFocus = false;
        Hit h = hitAt(x, y);
        if (h == null) return true;
        if (h.drag != null) { activeDrag = h; h.drag.accept((int) x); }
        else pressHit = h;
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (activeDrag != null) { activeDrag.drag.accept((int) click.x()); return true; }
        if (dragged || Math.abs(click.y() - pressY) > 5 || Math.abs(click.x() - pressX) > 5) {
            dragged = true;
            scrollTarget -= (float) dy; scroll = scrollTarget;
            hscroll -= (float) dx;
        }
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (pressHit != null && !dragged && pressHit.click != null) pressHit.click.run();
        pressHit = null; activeDrag = null; dragged = false;
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        scrollTarget -= (float) (vertical * 28);
        hscroll -= (float) (horizontal * 28);
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (!searchFocus) return super.charTyped(input);
        int cp = input.codepoint();
        if (cp >= 32 && cp != 127 && search.length() < 24) {
            search += new String(Character.toChars(cp));
            scroll = 0; scrollTarget = 0;
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (listenModule != null || listenSetting != null) {
            int val = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                if (listenModule != null) {
                    listenModule.setKeyCode(val);
                    if (listenModule.getKeybind() != null) listenModule.getKeybind().setKeyCode(val);
                } else listenSetting.setKeyCode(val);
            }
            listenModule = null; listenSetting = null;
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
                scroll = 0; scrollTarget = 0;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_ESCAPE) { searchFocus = false; return true; }
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            if (closeArmed || System.nanoTime() - openedNs > 1_500_000_000L) close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean keyReleased(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) closeArmed = true;
        return super.keyReleased(input);
    }

    // ------------------------------------------------------------------ util
    private static <K> float approach(Map<K, Float> map, K key, float target, float speed) {
        float v = map.getOrDefault(key, target);
        v += (target - v) * speed;
        if (Math.abs(target - v) < 0.004f) v = target;
        map.put(key, v);
        return v;
    }
}
