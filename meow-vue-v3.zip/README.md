# Meow Client + Meow GUI (dropdown layout)

The Aurora GUI is removed. The new Meow GUI uses the dropdown column layout: one column per category
side by side, light pills for enabled modules, and a dropdown arrow on every module for its settings.
Nothing else in the client was edited: `libs/meow-original.jar` is used as-is, and only
`cc/mochi/MeowMenu.class` is swapped so the menu opens the Meow screen.

- Open / close: **Right Shift**. The key is still handled by the original client, so no new bind was added.
  While the GUI is open Right Shift, Esc or the X button closes it.
- Top bar: MEOW, active module count, search, topography on/off (~), theme button (o), close button (x).
- Topography: contour lines inside every column, built once and only the visible part is drawn. Turn it off with ~ if it ever lags.
- Column header: tap to collapse / expand that category.
- Module: tap the name to toggle, tap the small arrow on its left to open its settings (keybind, sliders, colors...).
- Mobile: drag anywhere to pan sideways and scroll. Big touch targets.
- Less lag: module lists are cached, only visible columns and rows are drawn, no per-pixel effects.

## Build the jar (GitHub)
1. Create a GitHub repo and upload everything in this folder (keep `libs/` and `.github/`).
2. Repo > Actions > "build" > wait for green > download artifact **meow-client-jar**.
3. Put `meow-client-vue.jar` in your mods folder.

Local build: `gradle meowJar` (Gradle 9.x, Java 21). Output: `build/libs/meow-client-vue.jar`.

If it fails on "yarn not found", set `yarn_mappings` in gradle.properties to the build listed for 1.21.11 at https://fabricmc.net/develop.
If the Loom version fails, use the Loom version listed on the same page (build.gradle line 2).
