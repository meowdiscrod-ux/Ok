# Meow Client + Meow GUI (dropdown layout)

The Aurora GUI is removed. The new Meow GUI uses the dropdown column layout: one column per category
side by side, light pills for enabled modules, and a dropdown arrow on every module for its settings.
Nothing else in the client was edited: `libs/meow-original.jar` is used as-is, and only
`cc/mochi/MeowMenu.class` is swapped so the menu opens the Meow screen.

- Open / close: **Right Shift**. The key is still handled by the original client, so no new bind was added.
  While the GUI is open Right Shift, Esc or the X button closes it.
- Top bar: MEOW, active module count, search, topography on/off (~), theme button (o), close button (x).
- Topography: contour lines inside every column. OFF by default (it is the heaviest part to draw); turn it on with ~.
- Column header: tap to collapse / expand that category.
- Module: tap the name to toggle, tap the small arrow on its left to open its settings (keybind, sliders, colors...).
- Mobile: drag anywhere to pan sideways and scroll. Big touch targets.
- Less lag: module lists are cached, only visible columns and rows are drawn, shapes are merged into few fills (a column outline went from ~840 draw calls to ~32), and vanilla's menu blur is skipped.

## Build the jar (GitHub)
1. Create a GitHub repo and upload everything in this folder (keep `libs/` and `.github/`).
2. Repo > Actions > "build" > wait for green > download artifact **meow-client-jar**.
3. Put `meow-client-vue.jar` in your mods folder.

Local build: `gradle meowJar` (Gradle 9.x, Java 21). Output: `build/libs/meow-client-vue.jar`.

If it fails on "yarn not found", set `yarn_mappings` in gradle.properties to the build listed for 1.21.11 at https://fabricmc.net/develop.
If the Loom version fails, use the Loom version listed on the same page (build.gradle line 2).

## Friends and Theme Manager (inside the Meow GUI)
- Tapping **Friends** or **Theme Manager** no longer toggles the module. Toggling ran their onEnable, which opens the
  old ClickGui, and that is what closed and reopened the screen. They now just expand into their own panel.
- **Friends**: type any part of a name (`x` finds `Ahmed_xyng` if he is nearby) and press Enter or `+`. Matching nearby
  players are shown under the box; tap one to add him. `x` removes a friend, `clear` removes all, the colour chip cycles
  that friend's two-colour (mixed) pair. Friends are saved to `config/meow-friends.txt`. `cc.mochi.FriendManager` is
  replaced with a rewritten one (same methods), so every combat module that already skips friends uses the new list.
- **Theme Manager**: lists the client's own themes with their mixed-colour swatch. Picking one applies it to the client
  (ThemeManager) and recolours this GUI (pills fade through the theme's colours across the columns). `Classic` is the
  original white look. The pick is saved to `config/meow-gui-theme.txt`.
