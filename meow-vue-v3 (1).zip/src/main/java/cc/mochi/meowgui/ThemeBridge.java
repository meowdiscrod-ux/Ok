package cc.mochi.meowgui;

import cc.mochi.Theme;
import cc.mochi.ThemeManager;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Themes for the Meow GUI. Reads the client's own themes (cc.mochi.ThemeManager) so the list matches what the
 * rest of the client uses, and applies a pick back to it. Anything that touches java.awt lives in {@link Awt}
 * and is only loaded inside try/catch, so a launcher without AWT falls back to the built-in list instead of crashing.
 */
public final class ThemeBridge {
    private ThemeBridge() {}

    /** One theme as plain ints (ARGB): three gradient stops ("mixed colours") plus the accent. */
    public static final class Info {
        public final String name;
        public final int c1, c2, c3, accent;
        public final boolean light, classic;

        Info(String name, int c1, int c2, int c3, int accent, boolean light, boolean classic) {
            this.name = name; this.c1 = c1; this.c2 = c2; this.c3 = c3; this.accent = accent;
            this.light = light; this.classic = classic;
        }
    }

    /** null = Classic (the original white-pill look). */
    public static Info chosen;
    private static String savedName;
    private static boolean loaded;

    private static final Info CLASSIC = new Info("Classic", 0xFFE8E8EE, 0xFFB8B8C4, 0xFF6A6A78, 0xFFE6E6EE, false, true);

    private static Info b(String n, int c1, int c2, int c3) { return new Info(n, c1, c2, c3, c1, false, false); }

    private static List<Info> builtins() {
        List<Info> l = new ArrayList<>();
        l.add(b("Sunset", 0xFFFF6B6B, 0xFFFFA45E, 0xFFFFD86B));
        l.add(b("Ocean", 0xFF4DA3FF, 0xFF3FD0E0, 0xFF6BFFC9));
        l.add(b("Violet", 0xFFB57BFF, 0xFFFF7AE0, 0xFF7A8CFF));
        l.add(b("Emerald", 0xFF3FD07A, 0xFF9BE15D, 0xFF45E0C0));
        l.add(b("Rose", 0xFFFF6BA6, 0xFFFF9AC0, 0xFFFFC2A0));
        l.add(b("Neon", 0xFF00F5FF, 0xFFFF2E93, 0xFFB6FF00));
        l.add(b("Amber", 0xFFFFC857, 0xFFFF9A3C, 0xFFFF6B3C));
        l.add(b("Frost", 0xFF9BDFFF, 0xFFC4E9FF, 0xFFE4F6FF));
        return l;
    }

    /** Classic first, then every theme of the client (or the built-in list if the client's are unavailable). */
    public static List<Info> list() {
        List<Info> out = new ArrayList<>();
        out.add(CLASSIC);
        List<Info> real = null;
        try { real = Awt.read(); } catch (Throwable ignored) { }
        out.addAll(real != null && !real.isEmpty() ? real : builtins());
        if (!loaded) {
            loaded = true;
            savedName = readSaved();
            if (savedName != null) for (Info i : out) if (!i.classic && i.name.equals(savedName)) { chosen = i; break; }
        }
        return out;
    }

    public static boolean isChosen(Info i) {
        return chosen == null ? i.classic : (!i.classic && chosen.name.equals(i.name));
    }

    public static void choose(Info i) {
        if (i.classic) {
            chosen = null;
            savedName = "Classic";
        } else {
            chosen = i;
            savedName = i.name;
            try { ThemeManager.updateState(i.name); } catch (Throwable ignored) { }
        }
        writeSaved(savedName);
    }

    // ------------------------------------------------------------------ java.awt isolated here
    private static final class Awt {
        static List<Info> read() {
            Map<?, ?> m = ThemeManager.getThemeByString();
            List<Info> out = new ArrayList<>();
            if (m == null) return out;
            for (Object v : m.values()) {
                if (!(v instanceof Theme)) continue;
                Theme t = (Theme) v;
                out.add(new Info(t.name(), rgb(t.gradientStart()), rgb(t.gradientMid()), rgb(t.gradientEnd()),
                        rgb(t.accent()), t.light(), false));
            }
            return out;
        }

        static int rgb(java.awt.Color c) { return 0xFF000000 | (c.getRGB() & 0xFFFFFF); }
    }

    // ------------------------------------------------------------------ saved pick
    private static Path file() {
        try {
            return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meow-gui-theme.txt");
        } catch (Throwable t) {
            return Paths.get("config", "meow-gui-theme.txt");
        }
    }

    private static String readSaved() {
        try {
            Path p = file();
            if (!Files.isRegularFile(p)) return null;
            String s = new String(Files.readAllBytes(p), StandardCharsets.UTF_8).trim();
            return s.isEmpty() ? null : s;
        } catch (Throwable t) { return null; }
    }

    private static void writeSaved(String name) {
        try {
            Path p = file();
            if (p.getParent() != null) Files.createDirectories(p.getParent());
            Files.write(p, name.getBytes(StandardCharsets.UTF_8));
        } catch (Throwable ignored) { }
    }
}
