package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * Rewritten friend list. It REPLACES the original cc.mochi.FriendManager inside the final jar, and keeps
 * every public method the rest of the client calls (same names / signatures), so all the combat modules
 * that already ask "is this player a friend?" keep working and now see the improved list:
 *
 *  - friends are saved to config/meow-friends.txt and loaded on startup (the old list was lost on restart)
 *  - friends can be added by a PART of the name: typing "x" matches "Ahmed_xyng" if he is nearby
 *  - every friend has a two-colour (mixed) colour pair
 *
 * Lookups are by UUID and by lower-case name, exactly like before.
 */
public final class FriendManager {
    /** Live map (lower-case name -> entry), insertion ordered. Returned as-is by getFriendEntryByString(). */
    private static final Map<String, FriendEntry> friendEntryByString = new LinkedHashMap<>();
    private static final Map<String, Integer> colorIdx = new HashMap<>();

    /** Two-colour (mixed) pairs, ARGB. */
    private static final int[][] PAIRS = {
            {0xFF5EE6B0, 0xFF4DA3FF}, {0xFFFF6BA6, 0xFFFFB86B}, {0xFFB57BFF, 0xFF4DD0FF}, {0xFFFFE066, 0xFFFF6B6B},
            {0xFF6BFFB0, 0xFFE0FF6B}, {0xFFFF7AE0, 0xFF7A8CFF}, {0xFF58E1FF, 0xFFB6FF6B}, {0xFFFF9A5E, 0xFFFF4F8B},
            {0xFF9D8CFF, 0xFFFF8CD4}, {0xFF7CF4C0, 0xFF3FA9F5}, {0xFFFFD166, 0xFF06D6A0}, {0xFFEF476F, 0xFF8338EC},
    };

    /** A player that can be turned into a friend. uuid is null for a friend that is not online. */
    public static final class Candidate {
        public final String name;
        public final UUID uuid;
        public final boolean friend;
        public final int rank;

        Candidate(String name, UUID uuid, boolean friend, int rank) {
            this.name = name; this.uuid = uuid; this.friend = friend; this.rank = rank;
        }
    }

    static { load(); }

    private FriendManager() {}

    // ------------------------------------------------------------------ original API (kept as-is)

    public static boolean checkCondition(String name) {
        String k = key(name);
        return k != null && friendEntryByString.containsKey(k);
    }

    public static boolean testUUID(UUID uuid) {
        if (uuid == null) return false;
        for (FriendEntry e : friendEntryByString.values()) if (uuid.equals(e.uuid())) return true;
        return false;
    }

    public static boolean testPlayerEntity(PlayerEntity player) {
        if (player == null) return false;
        if (testUUID(player.getUuid())) return true;
        return checkCondition(player.getName().getString());
    }

    public static Map<String, FriendEntry> getFriendEntryByString() { return friendEntryByString; }

    public static List<FriendEntry> copyOf() { return List.copyOf(new ArrayList<>(friendEntryByString.values())); }

    /** Memory only (the client calls this on cleanup). Use clearAll() to also wipe the saved file. */
    public static void clear() { friendEntryByString.clear(); }

    public static Set<UUID> collect() {
        Set<UUID> out = new HashSet<>();
        for (FriendEntry e : friendEntryByString.values()) if (e.uuid() != null) out.add(e.uuid());
        return out;
    }

    /** Toggle by uuid. */
    public static void updateStateForUUID(UUID uuid) {
        if (testUUID(uuid)) updateStateForUUID3(uuid); else updateStateForUUID2(uuid);
    }

    /** Add by uuid (name looked up from the world when possible). */
    public static void updateStateForUUID2(UUID uuid) {
        if (uuid == null) return;
        String name = nameOf(uuid);
        updateStateForUUID4(uuid, name != null ? name : uuid.toString());
    }

    /** Remove by uuid. */
    public static void updateStateForUUID3(UUID uuid) {
        if (uuid == null) return;
        boolean changed = friendEntryByString.entrySet().removeIf(en -> uuid.equals(en.getValue().uuid()));
        if (changed) save();
    }

    /** Remove by name. */
    public static void updateState(String name) {
        String k = key(name);
        if (k == null) return;
        friendEntryByString.remove(k);
        colorIdx.remove(k);
        save();
    }

    /** Add by name only. */
    public static void updateState2(String name) { updateStateForUUID4(null, name); }

    /** Add / update by uuid + name. */
    public static void updateStateForUUID4(UUID uuid, String name) {
        String shown = trimmed(name);
        if (shown == null) return;
        String k = shown.toLowerCase(Locale.ROOT);
        FriendEntry old = friendEntryByString.get(k);
        UUID id = uuid != null ? uuid : (old == null ? null : old.uuid());
        String nm = old == null ? shown : old.name();
        friendEntryByString.put(k, new FriendEntry(id, nm));
        save();
    }

    // ------------------------------------------------------------------ new API (used by the Meow GUI)

    /** Online players (in the loaded world) whose name contains the typed text, best match first. */
    public static List<Candidate> onlineMatches(String query, boolean includeFriends) {
        List<Candidate> out = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.world == null) return out;
        String q = norm(query);
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            String nm = p.getName().getString();
            boolean fr = testPlayerEntity(p);
            if (fr && !includeFriends) continue;
            int idx = q.isEmpty() ? 0 : norm(nm).indexOf(q);
            if (idx < 0) continue;
            out.add(new Candidate(nm, p.getUuid(), fr, idx));
        }
        out.sort(Comparator.comparingInt((Candidate c) -> c.rank)
                .thenComparingInt(c -> c.name.length())
                .thenComparing(c -> c.name.toLowerCase(Locale.ROOT)));
        return out;
    }

    /**
     * Adds the best online match for the typed text (a part of the name is enough: "x" finds "Ahmed_xyng").
     * If nobody online matches but the text is a valid full name, it is added as an offline friend.
     * @return a short message for the GUI; starts with "Added" on success.
     */
    public static String addBest(String text) {
        String q = text == null ? "" : text.trim();
        if (q.isEmpty()) return "type a name";
        List<Candidate> all = onlineMatches(q, true);
        for (Candidate c : all) {
            if (!c.friend) {
                updateStateForUUID4(c.uuid, c.name);
                return "Added " + c.name;
            }
        }
        if (!all.isEmpty()) return all.get(0).name + " is already a friend";
        if (q.matches("[A-Za-z0-9_]{3,16}")) {
            if (checkCondition(q)) return q + " is already a friend";
            updateStateForUUID4(null, q);
            return "Added " + q + " (offline)";
        }
        return "no player matches '" + q + "'";
    }

    public static void clearAll() {
        friendEntryByString.clear();
        colorIdx.clear();
        save();
    }

    /** The friend's mixed colour pair {from, to}, ARGB. */
    public static int[] colors(String name) {
        String k = key(name);
        int i = 0;
        if (k != null) {
            Integer set = colorIdx.get(k);
            i = set != null ? set : Math.floorMod(k.hashCode(), PAIRS.length);
        }
        return PAIRS[Math.floorMod(i, PAIRS.length)];
    }

    public static void cycleColor(String name) {
        String k = key(name);
        if (k == null) return;
        Integer set = colorIdx.get(k);
        int cur = set != null ? set : Math.floorMod(k.hashCode(), PAIRS.length);
        colorIdx.put(k, (cur + 1) % PAIRS.length);
        save();
    }

    // ------------------------------------------------------------------ helpers

    private static String trimmed(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private static String key(String s) {
        String t = trimmed(s);
        return t == null ? null : t.toLowerCase(Locale.ROOT);
    }

    /** lower-case letters and digits only, so "ahmed xyng" still finds "Ahmed_xyng". */
    private static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = Character.toLowerCase(s.charAt(i));
            if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) b.append(ch);
        }
        return b.toString();
    }

    private static String nameOf(UUID uuid) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.world != null) {
                for (PlayerEntity p : mc.world.getPlayers()) if (uuid.equals(p.getUuid())) return p.getName().getString();
            }
        } catch (Throwable ignored) { }
        return null;
    }

    // ------------------------------------------------------------------ persistence

    private static Path file() {
        try {
            return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meow-friends.txt");
        } catch (Throwable t) {
            return Paths.get("config", "meow-friends.txt");
        }
    }

    private static void save() {
        try {
            Path p = file();
            if (p.getParent() != null) Files.createDirectories(p.getParent());
            List<String> lines = new ArrayList<>();
            for (Map.Entry<String, FriendEntry> en : friendEntryByString.entrySet()) {
                FriendEntry e = en.getValue();
                String nm = e.name();
                if (nm == null || nm.indexOf('|') >= 0 || nm.indexOf('\n') >= 0 || nm.indexOf('\r') >= 0) continue;
                Integer c = colorIdx.get(en.getKey());
                lines.add(nm + "|" + (e.uuid() == null ? "-" : e.uuid().toString()) + "|" + (c == null ? -1 : c));
            }
            Files.write(p, lines, StandardCharsets.UTF_8);
        } catch (Throwable ignored) { }
    }

    private static void load() {
        try {
            Path p = file();
            if (!Files.isRegularFile(p)) return;
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                String[] parts = line.split("\\|", -1);
                if (parts.length < 2) continue;
                String name = trimmed(parts[0]);
                if (name == null) continue;
                UUID id = null;
                try { if (!parts[1].equals("-")) id = UUID.fromString(parts[1]); } catch (Exception ignored) { }
                String k = name.toLowerCase(Locale.ROOT);
                friendEntryByString.put(k, new FriendEntry(id, name));
                if (parts.length >= 3) {
                    try { int c = Integer.parseInt(parts[2].trim()); if (c >= 0) colorIdx.put(k, c); } catch (Exception ignored) { }
                }
            }
        } catch (Throwable ignored) { }
    }
}
